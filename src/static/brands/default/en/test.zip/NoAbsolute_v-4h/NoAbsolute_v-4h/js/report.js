//for report pages leftpannel js

$(document).ready(function(){
			//hide the all of the element with class msg_body
			$(".hdnDiv").hide();
			//toggle the componenet with class msg_body
			$(".M-text-position3").click(function(){
				//image object
				var pImgObject=this.getElementsByTagName("div")[0].getElementsByTagName("img")[0];

				if(pImgObject.getAttribute("isHidden")=="1") {
					pImgObject.src="../images/arrow-down.gif";
					pImgObject.setAttribute("isHidden","0"); 
					pImgObject.title="Collapse";
				}else{
					pImgObject.src="../images/arrow-forward.gif";
					pImgObject.setAttribute("isHidden","1");
					pImgObject.title="Expand";
				}

				$(this).next(".hdnDiv").slideToggle(100);

			});
		});

var i=0;
var pct=100;
var pctScroll=79;
var intHide;
var intShow;
var speed=24;

function showHideMenu(){
	var panel=document.getElementById('left-pannelNew');
	if(panel.getAttribute("isHidden")=="1"){
		panel.setAttribute("isHidden","0");
		showmenu();
	}else{
		panel.setAttribute("isHidden","1");
		hidemenu();
	}
}

function showmenu()
{
	clearInterval(intHide);
	intShow=setInterval("show();",10);
}


function hidemenu()
{
	clearInterval(intShow);
	intHide=setInterval("hide();",10);
}

function show()
{
	if (i<-0)
	{
		i=i+speed;
		pct=pct-2.352;
		pctScroll=pctScroll-0.416;

		var pannelNew=document.getElementById("content2c");
		pannelNew.style.left=i+"px";
		pannelNew.style.width=pct+"%";
		var pannelScroll=document.getElementById("right-pannel-scroll");
		pannelScroll.style.width=pctScroll+"%";

		var sliderImage=document.getElementById('sliderImage');
		sliderImage.src="../images/slider.gif";
		sliderImage.title="Click to collapse";
	}
}

function hide()
{
	if (i>-192)
	{
		i=i-speed;
		pct=pct+2.352;
		pctScroll=pctScroll+0.416;

		var pannelNew=document.getElementById("content2c");
		pannelNew.style.left=i+"px";
		pannelNew.style.width=pct+"%";
		var pannelScroll=document.getElementById("right-pannel-scroll");
		pannelScroll.style.width=pctScroll+"%";

		var sliderImage=document.getElementById('sliderImage');
		sliderImage.src="../images/sliderExpand.gif";
		sliderImage.title="Click to expand";

	}

}
